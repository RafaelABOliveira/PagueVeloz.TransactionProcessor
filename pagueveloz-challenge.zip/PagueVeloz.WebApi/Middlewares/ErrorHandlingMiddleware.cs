﻿namespace PagueVeloz.WebApi.Middlewares
{
    public class ErrorHandlingMiddleware
    {
    }
}
