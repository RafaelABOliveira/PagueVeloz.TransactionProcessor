﻿namespace PagueVeloz.WebApi.Controllers
{
    public class TransactionsController
    {
    }
}
