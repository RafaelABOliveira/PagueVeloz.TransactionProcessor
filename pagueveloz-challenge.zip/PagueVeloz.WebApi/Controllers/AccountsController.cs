﻿namespace PagueVeloz.WebApi.Controllers
{
    public class AccountsController
    {
    }
}
