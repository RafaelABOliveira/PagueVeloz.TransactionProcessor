﻿namespace PagueVeloz.Core.Application.Commands
{
    internal class CreditCommand
    {
    }
}
