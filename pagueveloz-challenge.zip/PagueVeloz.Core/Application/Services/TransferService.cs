﻿namespace PagueVeloz.Core.Application.Services
{
    internal class TransferService
    {
    }
}
