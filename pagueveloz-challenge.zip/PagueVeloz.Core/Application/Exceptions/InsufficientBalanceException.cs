﻿namespace PagueVeloz.Core.Application.Exceptions
{
    internal class InsufficientBalanceException
    {
    }
}
