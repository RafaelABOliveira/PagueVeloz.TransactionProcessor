﻿namespace PagueVeloz.Core.Domain.Enums
{
    public enum AccountStatus
    {
        Active,
        Inactive,
        Blocked
    }
}
