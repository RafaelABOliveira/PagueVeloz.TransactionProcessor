﻿namespace PagueVeloz.Core.Domain.ValueObjects
{
    internal class Currency
    {
    }
}
