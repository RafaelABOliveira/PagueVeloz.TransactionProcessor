﻿namespace PagueVeloz.Core.Domain.Interfaces
{
    public interface IUnitOfWork
    {
    }
}
