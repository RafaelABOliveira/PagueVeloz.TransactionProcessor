﻿namespace PagueVeloz.Infrastructure.Resilience
{
    internal class RetryPolicy
    {
    }
}
